-- SQL RECOMMENDATIONS SCRIPT
-- Generated based on schema analysis

-- Add UNIQUE constraint to productos.codigo
ALTER TABLE productos ADD UNIQUE (codigo);

-- Fix telefono column default in sucursal
ALTER TABLE sucursal ALTER COLUMN telefono DROP DEFAULT;
ALTER TABLE sucursal MODIFY telefono VARCHAR(255) DEFAULT NULL;

-- Add FOREIGN KEY constraints in cuenta_items
ALTER TABLE cuenta_items ADD CONSTRAINT fk_cuenta FOREIGN KEY (cuenta_id) REFERENCES cuentas_clientes(id);
ALTER TABLE cuenta_items ADD CONSTRAINT fk_comanda FOREIGN KEY (comanda_id) REFERENCES comanda(id);
ALTER TABLE cuenta_items ADD CONSTRAINT fk_detalle_comanda FOREIGN KEY (detalle_comanda_id) REFERENCES detalle_comanda(id);